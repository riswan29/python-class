# kita dapat membuat looping for dengan lebih singkat dibanding code sebelumnya
baris = int(input("Masukkan jumlah baris: "))

for i in range(1, baris + 1):
    print("*" * i)
