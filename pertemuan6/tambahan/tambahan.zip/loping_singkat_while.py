# kita dapat membuat looping dengan lebih singkat dibanding code looping sebelumnya

baris = int(input("Masukkan jumlah baris: "))

i = 1
while i <= baris:
    print("*" * i)
    i = i + 1

