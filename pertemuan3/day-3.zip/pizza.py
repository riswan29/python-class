# kecil = S
# sedang = M
# besar = L

# harga S = 50rb
# harga M = 70rb
# harga S = 100rb
