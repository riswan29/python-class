# operator matematika
# + 
# -
# *
# /
# %
# **
# //


# penjumlahan
# print(12 + 13)

# pengurangan
# print(12 - 13)

# perkalian
# print(12 * 13)

# pemabagian
# print(12 / 13)

# floor
# print(12 // 13)


# % (modulus) = hasil sisa bagi
# print(7 % 3)
# 3 + 3 + 1

# nentuin bilangan genap
nilai = 7
# 2 + 2 + 2 + 1

if nilai % 2 == 0  : 
    #lakukan perintah jika benar
    print("NILAINYA GENAP")
else:
    print("nilainya ganjil")


