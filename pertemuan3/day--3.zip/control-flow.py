tinggi = 130

# pengkondisian menggunakan if else

# nilai = 6

# if nilai % 2 == 0  : 
#     #lakukan perintah jika benar
#     print("NILAINYA GENAP")
# else:
#     print("nilainya ganjil")

# if elif else

merekHP = "vivo"

if merekHP == "Xiomi":
    print("Ayo main game")
elif merekHP == "Iphone":
    print("Skuyy tiktokan")
else:
    print("Lu itu ngga diajak")
    
    